<?php header("Content-type: text/css"); ?>
<?php echo file_get_contents('style.css'); ?>