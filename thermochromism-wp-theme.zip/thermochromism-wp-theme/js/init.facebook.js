!(function($){
  window.fbAsyncInit = function () {
    FB.init({appId:'1510080215872330',status: true, cookie: true, xfbml: true });
  }  
  // FB.ui({
  //   method: 'share_open_graph',
  //   action_type: 'og.likes',
  //   action_properties: JSON.stringify({
  //       object:'https://developers.facebook.com/docs/',
  //   })
  // }, function(response){});
})(jQuery);
