( function  ($) {
  $( function() {
          $( '.main-head .title, .sub-head .title' ).each( function () {
             var $tit = $( this );
             
          } );
  } );
} )(jQuery)